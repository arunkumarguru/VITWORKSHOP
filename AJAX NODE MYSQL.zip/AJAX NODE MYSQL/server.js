const express=require("express");
const mysql=require("mysql2");
const cors=require("cors");
const app=express();

const db=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"cat"
});

app.use(cors());

app.get("/class3",(req,res)=>{
    let room=req.query.room;
    db.query("SELECT * FROM class3 WHERE classnum=?",[room],(err,result)=>{
        if(err) return res.status(500).send(err);
        res.json(result);
    });
});

app.listen(3000,()=>console.log("Server running on port 3000"));