# FinTrack — React + Express + MongoDB demo

## Requirements
- Docker Desktop installed and running
- Node.js is NOT required for the backend if you run it in Docker, but this simple demo runs the React dev server locally, so install Node.js for the `web` folder.

## 1. Start MongoDB
From the project root:
```bash
docker compose up -d
```

## 2. Start the backend
Open a terminal:
```bash
cd api
npm install
npm run dev
```
API: http://localhost:4000/api/health

## 3. Start the React frontend
Open a second terminal from the project root:
```bash
cd web
npm install
npm run dev
```
Open the Vite URL printed in the terminal (usually http://localhost:5173).

## What to demonstrate
1. Add an income transaction (e.g. Salary, 25000).
2. Add an expense transaction (e.g. Food, 500).
3. Show that totals update automatically.
4. Refresh the browser: transactions remain because they are saved in MongoDB.
5. Delete a transaction and show the list updates.
6. Open http://localhost:4000/api/health to see backend/database status.

## Architecture
React (browser) -> Express REST API (Node.js, port 4000) -> MongoDB (port 27017).

Note: This demo is for teaching only. It has no authentication and should not be used for real financial records.
