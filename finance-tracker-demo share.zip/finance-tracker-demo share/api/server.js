const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

const transactionSchema = new mongoose.Schema({
  type: { type: String, enum: ["Income", "Expense"], required: true },
  amount: { type: Number, required: true, min: 0.01 },
  category: { type: String, required: true, trim: true },
  description: { type: String, default: "", trim: true },
  date: { type: Date, default: Date.now }
}, { timestamps: true });

const Transaction = mongoose.model("Transaction", transactionSchema);

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    database: mongoose.connection.readyState === 1 ? "connected" : "disconnected"
  });
});

app.get("/api/transactions", async (req, res) => {
  try {
    const transactions = await Transaction.find().sort({ date: -1, createdAt: -1 });
    res.json(transactions);
  } catch {
    res.status(500).json({ message: "Could not load transactions" });
  }
});

app.post("/api/transactions", async (req, res) => {
  try {
    const { type, amount, category, description } = req.body;
    if (!["Income", "Expense"].includes(type) ||
        !Number.isFinite(Number(amount)) || Number(amount) <= 0 ||
        !String(category || "").trim()) {
      return res.status(400).json({ message: "Enter a valid type, positive amount, and category." });
    }
    const transaction = await Transaction.create({
      type, amount: Number(amount), category: String(category).trim(),
      description: String(description || "").trim()
    });
    res.status(201).json(transaction);
  } catch {
    res.status(500).json({ message: "Could not save transaction" });
  }
});

app.delete("/api/transactions/:id", async (req, res) => {
  try {
    const deleted = await Transaction.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Transaction not found" });
    res.json({ message: "Transaction deleted" });
  } catch {
    res.status(400).json({ message: "Invalid transaction ID" });
  }
});

const port = process.env.PORT || 4000;
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB connected");
    app.listen(port, "0.0.0.0", () => console.log(`API running at http://localhost:${port}`));
  })
  .catch(err => {
    console.error("MongoDB connection failed:", err.message);
    process.exit(1);
  });
