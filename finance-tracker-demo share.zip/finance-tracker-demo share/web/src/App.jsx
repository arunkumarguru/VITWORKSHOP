import React, { useEffect, useMemo, useState } from "react";
//import { useEffect, useMemo, useState } from "react";
import { Wallet, TrendingUp, TrendingDown, Plus, Trash2, ArrowUpRight, ArrowDownRight, RefreshCw } from "lucide-react";

const API = "http://localhost:4000/api";
const money = n => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(n);

export default function App() {
  const [transactions, setTransactions] = useState([]);
  const [type, setType] = useState("Expense");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Food");
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function loadTransactions() {
    try {
      const res = await fetch(`${API}/transactions`);
      if (!res.ok) throw new Error("API request failed");
      setTransactions(await res.json());
      setMessage("");
    } catch {
      setMessage("Cannot reach the API. Check that MongoDB and the backend are running.");
    }
  }
  useEffect(() => { loadTransactions(); }, []);

  const totals = useMemo(() => {
    const income = transactions.filter(t => t.type === "Income").reduce((s, t) => s + t.amount, 0);
    const expenses = transactions.filter(t => t.type === "Expense").reduce((s, t) => s + t.amount, 0);
    return { income, expenses, balance: income - expenses };
  }, [transactions]);

  async function addTransaction(e) {
    e.preventDefault();
    setBusy(true); setMessage("");
    try {
      const res = await fetch(`${API}/transactions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, amount: Number(amount), category, description })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Could not save transaction");
      setTransactions(old => [data, ...old]);
      setAmount(""); setDescription("");
      setMessage("Transaction saved to MongoDB.");
    } catch (err) {
      setMessage(err.message || "Could not save transaction.");
    } finally { setBusy(false); }
  }

  async function deleteTransaction(id) {
    try {
      const res = await fetch(`${API}/transactions/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Delete failed");
      setTransactions(old => old.filter(t => t._id !== id));
      setMessage("Transaction deleted.");
    } catch { setMessage("Could not delete transaction."); }
  }

  return <main className="shell">
    <header className="topbar">
      <div className="brand"><div className="brand-icon"><Wallet size={24}/></div><div><h1>FinTrack</h1><p>Personal finance dashboard</p></div></div>
      <button className="refresh" onClick={loadTransactions}><RefreshCw size={16}/> Refresh data</button>
    </header>

    <section className="welcome"><div><span className="eyebrow">YOUR MONEY, CLEARLY</span><h2>Good overview.<br/><em>Better decisions.</em></h2><p>Track income and expenses in one simple place.</p></div><div className="welcome-art"><div className="art-circle"><Wallet size={42}/></div><div className="art-chip">Monthly overview <b>↗</b></div></div></section>

    <section className="summary">
      <article className="stat balance"><div className="stat-head"><span>Total balance</span><span className="stat-icon"><Wallet size={19}/></span></div><strong>{money(totals.balance)}</strong><small>Income minus expenses</small></article>
      <article className="stat"><div className="stat-head"><span>Total income</span><span className="stat-icon green"><TrendingUp size={19}/></span></div><strong>{money(totals.income)}</strong><small className="positive">Money received</small></article>
      <article className="stat"><div className="stat-head"><span>Total expenses</span><span className="stat-icon red"><TrendingDown size={19}/></span></div><strong>{money(totals.expenses)}</strong><small className="negative">Money spent</small></article>
    </section>

    <section className="content-grid">
      <form className="panel form-panel" onSubmit={addTransaction}>
        <div className="panel-title"><div><span className="eyebrow">QUICK ENTRY</span><h3>Add transaction</h3></div><span className="plus-icon"><Plus size={20}/></span></div>
        <div className="segmented"><button type="button" className={type === "Expense" ? "selected expense" : ""} onClick={() => setType("Expense")}><ArrowDownRight size={16}/> Expense</button><button type="button" className={type === "Income" ? "selected income" : ""} onClick={() => setType("Income")}><ArrowUpRight size={16}/> Income</button></div>
        <label>Amount (₹)<input required type="number" min="0.01" step="0.01" placeholder="e.g. 1250" value={amount} onChange={e => setAmount(e.target.value)}/></label>
        <label>Category<select value={category} onChange={e => setCategory(e.target.value)}>{["Food","Travel","Salary","Shopping","Bills","Education","Health","Other"].map(x => <option key={x}>{x}</option>)}</select></label>
        <label>Description <span className="optional">Optional</span><input placeholder="What was it for?" value={description} onChange={e => setDescription(e.target.value)}/></label>
        <button className="submit" disabled={busy}>{busy ? "Saving…" : <><Plus size={17}/> Save transaction</>}</button>
        {message && <p className="message" role="status">{message}</p>}
      </form>

      <section className="panel transactions-panel">
        <div className="panel-title"><div><span className="eyebrow">ACTIVITY</span><h3>Recent transactions</h3></div><span className="count">{transactions.length} total</span></div>
        {transactions.length === 0 ? <div className="empty"><div className="empty-icon"><Wallet size={25}/></div><b>No transactions yet</b><p>Add your first income or expense to see it here.</p></div> :
          <div className="transaction-list">{transactions.map(t => <article className="transaction" key={t._id}><div className={`transaction-icon ${t.type.toLowerCase()}`}>{t.type === "Income" ? <ArrowDownRight size={19}/> : <ArrowUpRight size={19}/>}</div><div className="transaction-info"><b>{t.description || t.category}</b><span>{t.category} · {new Date(t.date || t.createdAt).toLocaleDateString()}</span></div><div className={`transaction-amount ${t.type.toLowerCase()}`}>{t.type === "Income" ? "+" : "−"}{money(t.amount)}</div><button className="delete" title="Delete transaction" aria-label="Delete transaction" onClick={() => deleteTransaction(t._id)}><Trash2 size={16}/></button></article>)}</div>}
      </section>
    </section>
    <footer><span><i/> Connected app demo</span><span>React · Express · MongoDB</span></footer>
  </main>;
}
