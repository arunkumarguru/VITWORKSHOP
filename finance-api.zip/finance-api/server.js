const express = require("express");
const app = express();
const PORT = 5000;

//Step 2: Your first route
app.get("/", (req, res) => {
  res.send("Finance API is running");
});

//JSON data for transactions
const transactions = [
  { id: 1, type: "Income", amount: 25000,
    category: "Salary", description: "salary" },
  { id: 2, type: "Expense", amount: 500,
    category: "Food", description: "saravana bhavan" },
];

//Step 4: A GET request
/*app.get("/api/transactions", (req, res) => {
  res.json(transactions);
});*/

app.get("/api/transactions", (req, res) => {
  const type = req.query.type;   // e.g. ?type=Expense

  if (!type) {
    return res.json(transactions);
  }

  const result = transactions.filter(t => t.type === type);
  res.json(result);
});

//Step 4: Filter with a query
app.get("/api/transactions", (req, res) => {
  const type = req.query.type;   // e.g. ?type=Expense
   console.log("Query type:", type);

  if (!type) {
    return res.json(transactions);
  }

  const result = transactions.filter(t => t.type === type);
  res.json(result);
});


app.use(express.json());   // read JSON bodies

//Step 5: A POST request

app.post("/api/transactions", (req, res) => {
  const newItem = {
    id: transactions.length + 1,
    type: req.body.type,
    amount: req.body.amount,
    category: req.body.category,
    description: req.body.description,
  };
  transactions.push(newItem);
  res.status(201).json(newItem);
});

app.listen(PORT, () => {
  console.log("Server running on port " + PORT);
});
