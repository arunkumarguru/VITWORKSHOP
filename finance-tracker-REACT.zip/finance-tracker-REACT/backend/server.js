import express from "express";
import mongoose from "mongoose";

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI =
  process.env.MONGO_URI || "mongodb://localhost:27017/finance_tracker";

app.use(express.json());

const transactionSchema = new mongoose.Schema(
  {
    amount: { type: Number, required: true, min: 0.01 },
    type: { type: String, enum: ["income", "expense"], required: true },
    category: { type: String, required: true, trim: true },
    description: { type: String, trim: true, default: "" }
  },
  { timestamps: true }
);

const Transaction = mongoose.model("Transaction", transactionSchema);

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "finance-tracker-api" });
});

app.get("/api/transactions", async (_req, res) => {
  try {
    const transactions = await Transaction.find().sort({ createdAt: -1 });
    res.json(transactions);
  } catch (error) {
    console.error("Could not load transactions:", error);
    res.status(500).json({ message: "Could not load transactions." });
  }
});

app.post("/api/transactions", async (req, res) => {
  try {
    const { amount, type, category, description = "" } = req.body;
    const numericAmount = Number(amount);

    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      return res.status(400).json({ message: "Enter an amount greater than zero." });
    }
    if (!["income", "expense"].includes(type)) {
      return res.status(400).json({ message: "Choose income or expense." });
    }
    if (typeof category !== "string" || !category.trim()) {
      return res.status(400).json({ message: "Choose a category." });
    }

    const transaction = await Transaction.create({
      amount: numericAmount,
      type,
      category: category.trim(),
      description: String(description).trim()
    });

    res.status(201).json(transaction);
  } catch (error) {
    console.error("Could not save transaction:", error);
    res.status(500).json({ message: "Could not save transaction." });
  }
});

app.delete("/api/transactions/:id", async (req, res) => {
  try {
    const deleted = await Transaction.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "Transaction not found." });
    }
    res.json({ message: "Transaction deleted.", id: req.params.id });
  } catch (error) {
    res.status(400).json({ message: "Invalid transaction ID." });
  }
});


// Serve the production React build from the same Express server.
app.use(express.static("public"));

// For browser routes, return React's index.html.
// API routes above keep their own JSON responses.
app.get("*", (_req, res) => {
  res.sendFile(new URL("./public/index.html", import.meta.url).pathname);
});

async function start() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log("Connected to MongoDB");
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Finance Tracker API listening on port ${PORT}`);
    });
  } catch (error) {
    console.error("Could not connect to MongoDB:", error);
    process.exit(1);
  }
}

start();
