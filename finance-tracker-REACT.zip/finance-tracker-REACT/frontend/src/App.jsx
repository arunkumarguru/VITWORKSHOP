import { useEffect, useMemo, useState } from "react";
import {
  ArrowDownLeft, ArrowUpRight, Wallet, Plus, Trash2, TrendingUp,
  TrendingDown, Search, RefreshCw, CircleAlert, CheckCircle2, LoaderCircle
} from "lucide-react";

const money = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2
  }).format(amount || 0);

function TransactionForm({ onAdd, status }) {
  const [type, setType] = useState("expense");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Food");
  const [description, setDescription] = useState("");

  async function handleSubmit(event) {
    event.preventDefault();
    const saved = await onAdd({
      amount: Number(amount),
      type,
      category,
      description
    });
    if (saved) {
      setAmount("");
      setDescription("");
    }
  }

  return (
    <form className="form-card" onSubmit={handleSubmit}>
      <div className="section-heading">
        <div>
          <p className="eyebrow">NEW ENTRY</p>
          <h2>Add transaction</h2>
        </div>
        <span className="icon-chip"><Plus size={20} /></span>
      </div>

      <div className="type-switch" role="group" aria-label="Transaction type">
        <button type="button" className={type === "expense" ? "type-option active expense" : "type-option"} onClick={() => setType("expense")}>
          <ArrowUpRight size={17} /> Expense
        </button>
        <button type="button" className={type === "income" ? "type-option active income" : "type-option"} onClick={() => setType("income")}>
          <ArrowDownLeft size={17} /> Income
        </button>
      </div>

      <label className="field-label" htmlFor="amount">Amount (₹)</label>
      <div className="amount-field">
        <span>₹</span>
        <input id="amount" type="number" min="0.01" step="0.01" placeholder="500.00" value={amount} onChange={(e) => setAmount(e.target.value)} required />
      </div>

      <div className="field-grid">
        <div>
          <label className="field-label" htmlFor="category">Category</label>
          <select id="category" value={category} onChange={(e) => setCategory(e.target.value)}>
            {["Food", "Transport", "Shopping", "Bills", "Salary", "Freelance", "Education", "Health", "Other"].map((item) => <option key={item}>{item}</option>)}
          </select>
        </div>
        <div>
          <label className="field-label" htmlFor="description">Description</label>
          <input id="description" type="text" maxLength="100" placeholder="e.g. Saravana Bhavan" value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
      </div>

      <button className="primary-button" type="submit" disabled={status === "loading"}>
        {status === "loading" ? <><LoaderCircle className="spin" size={18} /> Saving...</> : <><Plus size={18} /> Save transaction</>}
      </button>
      <p className="form-footnote">Your entry is stored in the database.</p>
    </form>
  );
}

function SummaryCard({ title, value, kind, icon: Icon, note }) {
  return (
    <article className={`summary-card ${kind}`}>
      <div className="summary-top">
        <span className="summary-label">{title}</span>
        <span className="summary-icon"><Icon size={20} /></span>
      </div>
      <div className="summary-value">{money(value)}</div>
      <p className="summary-note">{note}</p>
    </article>
  );
}

function TransactionList({ transactions, onDelete, filter, setFilter, deletingId }) {
  const filtered = transactions.filter((item) => {
    const query = filter.trim().toLowerCase();
    return !query || item.category.toLowerCase().includes(query) || (item.description || "").toLowerCase().includes(query) || item.type.includes(query);
  });

  return (
    <section className="list-card">
      <div className="list-header">
        <div>
          <p className="eyebrow">YOUR ACTIVITY</p>
          <h2>Recent transactions <span className="count">{transactions.length}</span></h2>
        </div>
        <div className="search-box">
          <Search size={17} />
          <input aria-label="Search transactions" value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Search..." />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <span className="empty-icon"><Wallet size={24} /></span>
          <strong>{transactions.length === 0 ? "No transactions yet" : "No matching transactions"}</strong>
          <p>{transactions.length === 0 ? "Add your first entry using the form." : "Try another category or description."}</p>
        </div>
      ) : (
        <div className="transaction-table">
          <div className="table-row table-head">
            <span>TRANSACTION</span><span>CATEGORY</span><span>DATE</span><span className="align-right">AMOUNT</span><span></span>
          </div>
          {filtered.map((item) => (
            <div className="table-row" key={item._id}>
              <div className="transaction-name">
                <span className={`transaction-icon ${item.type}`}>{item.type === "income" ? <ArrowDownLeft size={18} /> : <ArrowUpRight size={18} />}</span>
                <span><strong>{item.description || item.category}</strong><small>{item.type === "income" ? "Income" : "Expense"}</small></span>
              </div>
              <span><span className="category-pill">{item.category}</span></span>
              <span className="date-cell">{new Date(item.createdAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</span>
              <strong className={`amount-cell ${item.type} align-right`}>{item.type === "income" ? "+" : "−"}{money(item.amount)}</strong>
              <button className="delete-button" aria-label={`Delete ${item.description || item.category}`} title="Delete transaction" onClick={() => onDelete(item._id)} disabled={deletingId === item._id}>
                {deletingId === item._id ? <LoaderCircle size={16} className="spin" /> : <Trash2 size={16} />}
              </button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

export default function App() {
  const [transactions, setTransactions] = useState([]);
  const [status, setStatus] = useState("loading");
  const [message, setMessage] = useState("");
  const [filter, setFilter] = useState("");
  const [deletingId, setDeletingId] = useState("");

  async function loadTransactions() {
    setStatus("loading");
    setMessage("");
    try {
      const response = await fetch("/api/transactions");
      if (!response.ok) throw new Error("Could not load transactions. Check that the server is running.");
      const data = await response.json();
      setTransactions(data);
      setStatus("idle");
    } catch (error) {
      setStatus("error");
      setMessage(error.message || "Could not connect to the server.");
    }
  }

  useEffect(() => {
    loadTransactions();
  }, []);

  const totals = useMemo(() => transactions.reduce((acc, item) => {
    if (item.type === "income") acc.income += item.amount;
    else acc.expenses += item.amount;
    acc.balance = acc.income - acc.expenses;
    return acc;
  }, { income: 0, expenses: 0, balance: 0 }), [transactions]);

  async function addTransaction(transaction) {
    setStatus("loading");
    setMessage("");
    try {
      const response = await fetch("/api/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(transaction)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not save transaction.");
      setTransactions((current) => [data, ...current]);
      setStatus("success");
      setMessage(`${transaction.type === "income" ? "Income" : "Expense"} ${money(data.amount)} saved under ${data.category}.`);
      return true;
    } catch (error) {
      setStatus("error");
      setMessage(error.message || "Could not reach the server. Try again.");
      return false;
    }
  }

  async function deleteTransaction(id) {
    setDeletingId(id);
    setMessage("");
    try {
      const response = await fetch(`/api/transactions/${id}`, { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not delete transaction.");
      setTransactions((current) => current.filter((item) => item._id !== id));
      setStatus("success");
      setMessage("Transaction deleted.");
    } catch (error) {
      setStatus("error");
      setMessage(error.message || "Could not delete transaction.");
    } finally {
      setDeletingId("");
    }
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <a className="brand" href="/" aria-label="Finwise home">
          <span className="brand-mark"><Wallet size={21} /></span>
          <span>finwise<span className="brand-dot">.</span><small>PERSONAL FINANCE</small></span>
        </a>
        <div className="topbar-right"><span className="live-dot"></span> Local demo <span className="avatar">ST</span></div>
      </header>

      <section className="welcome-row">
        <div>
          <p className="eyebrow">YOUR FINANCIAL OVERVIEW</p>
          <h1>Money, made <span>clear.</span></h1>
          <p className="welcome-subtitle">Track your spending, understand your habits, and stay in control.</p>
        </div>
        <button className="refresh-button" onClick={loadTransactions} disabled={status === "loading"}><RefreshCw size={16} /> Refresh data</button>
      </section>

      <section className="summary-grid">
        <SummaryCard title="Total balance" value={totals.balance} kind="balance" icon={Wallet} note="Income minus expenses" />
        <SummaryCard title="Total income" value={totals.income} kind="income" icon={TrendingUp} note="Money coming in" />
        <SummaryCard title="Total expenses" value={totals.expenses} kind="expense" icon={TrendingDown} note="Money going out" />
      </section>

      {message && (
        <div className={`status-banner ${status === "error" ? "error" : "success"}`} role="status">
          {status === "error" ? <CircleAlert size={19} /> : <CheckCircle2 size={19} />}
          <span>{message}</span>
          {status === "error" && <button onClick={loadTransactions}>Retry</button>}
        </div>
      )}

      {status === "loading" && transactions.length === 0 && (
        <div className="loading-banner"><LoaderCircle size={18} className="spin" /> Loading transactions...</div>
      )}

      <div className="content-grid">
        <TransactionForm onAdd={addTransaction} status={status} />
        <TransactionList transactions={transactions} onDelete={deleteTransaction} filter={filter} setFilter={setFilter} deletingId={deletingId} />
      </div>

      <footer className="app-footer"><span>FINWISE · WORKSHOP DEMO</span><span>React + Express + MongoDB + Docker</span></footer>
    </main>
  );
}
