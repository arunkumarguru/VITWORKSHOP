# Finance Tracker — No Nginx Version

This workshop version uses **React + Vite, Node.js + Express, MongoDB and Docker Compose**. Nginx is not used.

## Requirements
- Docker Desktop installed and running
- Web browser
- Internet access for the first build to download Docker images and npm packages

## Run
1. Extract `finance-tracker-no-nginx.zip`.
2. Open a terminal in the extracted `finance-tracker-no-nginx` folder (the folder containing `docker-compose.yml`).
3. Run:

   ```bash
   docker compose up --build
   ```

4. Wait for the build and services to finish starting.
5. Open **http://localhost:8080**.

Express serves the built React files and handles the `/api/transactions` endpoints from the same server/port.

## Demo
- Add an expense: amount ₹500, category Food, description Saravana Bhavan.
- Add income, e.g. ₹30,000 under Salary, and observe the totals.
- Refresh the browser to show MongoDB persistence.
- To demonstrate the error state, open a second terminal in this folder and run:

  ```bash
  docker compose stop app
  ```

  Try a request in the browser, then restart:

  ```bash
  docker compose start app
  ```

## Stop
Press `Ctrl+C` in the terminal running Compose, then run:

```bash
docker compose down
```

Database data persists in the named Docker volume. To delete the containers and database data:

```bash
docker compose down -v
```

## Architecture
Browser → Node.js + Express (serves React build and API) → MongoDB

## Learning points
- `useState`: form inputs, transactions, loading/success/error status
- `useEffect`: load transactions on initial mount
- Props: form callbacks and transaction list
- Controlled inputs, `fetch`, `async/await`, API validation
- MongoDB persistence and Docker Compose

This is a workshop demo, not a production financial service. It has no login or authorization.
